#!/bin/bash

JSONC_IPK="json-c_0.12.1+20160607_armhf.ipk"
MOSQT_IPK="mosquitto_2.0.0_armhf.ipk"

# install the ipk dependency files
echo "installing the required ipk files"
opkg install --force-reinstall ./ipk/*

# move the config and log directory
echo "setting up the config file and log directory"
cp -r ./etc/kbus-api /etc/

# now move the binary file and set permissions
echo "moving the bin file to /bin directory"
cp ./bin/kbus-api /bin/ && chmod +x /bin/kbus-api

# move the startup scripts
echo "creating startup script to run on boot"
cp ./etc/init.d/kbus-apid /etc/init.d && chmod +x /etc/init.d/kbus-apid
ln -s /etc/init.d/kbus-apid /etc/rc.d/S99_kbus_api

 echo "cleaning up"
rm -r ./etc && rm -r ./bin && rm -r ./ipk && rm kbus-api-installer.tar.gz && rm installer.sh
